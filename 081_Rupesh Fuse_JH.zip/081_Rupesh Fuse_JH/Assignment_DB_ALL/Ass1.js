const url="";
let data={
    host:"localhost",
    user:"rupesh",
    password:"cdac",
    database:"rupesh",
    port:3306
};
const mysql =require('mysql2');
const con=mysql.createConnection(data);

console.log("Database Connected");